import React from "react";
import type { DatasetDetailResponse } from "../../../lib/api/types";
import { SchemaDiff } from "../components/schema-diff";

export function SchemaTab({ dataset }: { dataset: DatasetDetailResponse }) {
  return (
    <div className="grid grid-cols-1 gap-4">
      <div className="rounded-2xl border bg-card p-5">
        <div className="text-sm font-semibold">Current schema</div>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs text-muted-foreground">
              <tr>
                <th className="py-2 pr-4">Column</th>
                <th className="py-2 pr-4">Type</th>
                <th className="py-2 pr-4">Nullable</th>
              </tr>
            </thead>
            <tbody>
              {dataset.schema.map((c) => (
                <tr key={c.name} className="border-t">
                  <td className="py-2 pr-4 font-medium">{c.name}</td>
                  <td className="py-2 pr-4 font-mono text-xs">{c.type}</td>
                  <td className="py-2 pr-4">{c.nullable ? "Yes" : "No"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <SchemaDiff />
    </div>
  );
}
