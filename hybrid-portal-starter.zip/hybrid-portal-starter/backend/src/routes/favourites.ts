import { Router } from 'express';
import { z } from 'zod';
import { PrismaClient } from '@prisma/client';
const router = Router();

const bodySchema = z.object({
  userEmail: z.string().email(),
  entityUrn: z.string(),
  note: z.string().optional(),
});

router.post('/', async (req, res) => {
  const parse = bodySchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: parse.error.errors });
  const { userEmail, entityUrn, note } = parse.data;
  const prisma: PrismaClient = (req.app.get('prisma') as PrismaClient);

  // upsert user
  const user = await prisma.user.upsert({
    where: { email: userEmail },
    update: { name: userEmail.split('@')[0] },
    create: { email: userEmail, name: userEmail.split('@')[0] },
  });

  const fav = await prisma.favourite.create({
    data: {
      userId: user.id,
      entityUrn,
      note,
    }
  });
  res.json(fav);
});

router.get('/:email', async (req, res) => {
  const email = String(req.params.email);
  const prisma: PrismaClient = (req.app.get('prisma') as PrismaClient);
  const user = await prisma.user.findUnique({ where: { email }, include: { favourites: true }});
  if (!user) return res.json([]);
  res.json(user.favourites);
});

export default router;
