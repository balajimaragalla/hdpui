import React from "react";

export function SchemaDiff() {
  return (
    <div className="rounded-2xl border bg-card p-5">
      <div className="text-sm font-semibold">Schema evolution</div>
      <div className="mt-1 text-xs text-muted-foreground">
        Plug this into your backend diff endpoint (e.g. /catalogue/datasets/:id/schema/compare?snapshotA=...&snapshotB=...).
      </div>

      <div className="mt-4 rounded-2xl border bg-background p-4 font-mono text-xs">
        {"// Example (placeholder)
"}
        {"added:  trade_currency STRING
"}
        {"changed: trade_date DATE -> TIMESTAMP
"}
        {"removed: legacy_flag BOOLEAN
"}
      </div>
    </div>
  );
}
