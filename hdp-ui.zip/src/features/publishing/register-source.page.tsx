import React from "react";
import { Page } from "../../components/layout/page";
import { useMutation, useQuery } from "@tanstack/react-query";
import { endpoints } from "../../lib/api/endpoints";
import { queryClient } from "../../lib/query-client";
import type { AuthorityStatement } from "../../lib/api/types";

export function RegisterSourcePage() {
  const { data } = useQuery({ queryKey: ["authorityStatements"], queryFn: () => endpoints.authorityStatements() });

  const [stmt, setStmt] = React.useState<AuthorityStatement>({
    statementType: "RegisteredAuthorisedSource",
    applicationId: "",
    systemName: "",
    dataDomain: "",
    scope: "dataset",
    scopeRef: "",
    validFrom: new Date().toISOString().slice(0, 10),
    controls: { residency: "UK", retention: "7y", accessModel: "ABAC" }
  });

  const save = useMutation({
    mutationFn: async () => endpoints.upsertAuthorityStatement(stmt),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["authorityStatements"] });
      setStmt({ ...stmt, applicationId: "", systemName: "", scopeRef: "" });
    }
  });

  return (
    <Page title="Authority statements" subtitle="Registered Authorised Source / Distributor statements for lineage + compliance">
      <div className="grid grid-cols-1 gap-4">
        <div className="rounded-2xl border bg-card p-5">
          <div className="text-sm font-semibold">Create / update</div>
          <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
            <Field label="Statement type">
              <select className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
                value={stmt.statementType}
                onChange={(e) => setStmt({ ...stmt, statementType: e.target.value as any })}>
                <option value="RegisteredAuthorisedSource">Registered Authorised Source</option>
                <option value="RegisteredAuthorisedDistributor">Registered Authorised Distributor</option>
              </select>
            </Field>

            <Field label="Application (NAR ID)">
              <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm font-mono"
                value={stmt.applicationId} onChange={(e) => setStmt({ ...stmt, applicationId: e.target.value })} />
            </Field>

            <Field label="System name">
              <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
                value={stmt.systemName} onChange={(e) => setStmt({ ...stmt, systemName: e.target.value })} />
            </Field>

            <Field label="Data domain">
              <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
                value={stmt.dataDomain} onChange={(e) => setStmt({ ...stmt, dataDomain: e.target.value })} />
            </Field>

            <Field label="Scope">
              <select className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
                value={stmt.scope} onChange={(e) => setStmt({ ...stmt, scope: e.target.value as any })}>
                <option value="dataset">Dataset</option>
                <option value="topic">Topic</option>
                <option value="schema">Schema</option>
                <option value="view">View</option>
              </select>
            </Field>

            <Field label="Scope reference">
              <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm font-mono"
                value={stmt.scopeRef} onChange={(e) => setStmt({ ...stmt, scopeRef: e.target.value })} />
            </Field>

            <Field label="Residency">
              <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
                value={stmt.controls.residency} onChange={(e) => setStmt({ ...stmt, controls: { ...stmt.controls, residency: e.target.value } })} />
            </Field>

            <Field label="Retention">
              <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
                value={stmt.controls.retention} onChange={(e) => setStmt({ ...stmt, controls: { ...stmt.controls, retention: e.target.value } })} />
            </Field>

            <Field label="Access model">
              <select className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
                value={stmt.controls.accessModel}
                onChange={(e) => setStmt({ ...stmt, controls: { ...stmt.controls, accessModel: e.target.value as any } })}>
                <option value="RBAC">RBAC</option>
                <option value="ABAC">ABAC</option>
                <option value="Hybrid">Hybrid</option>
              </select>
            </Field>

            <Field label="Valid from">
              <input type="date" className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
                value={stmt.validFrom} onChange={(e) => setStmt({ ...stmt, validFrom: e.target.value })} />
            </Field>

            <div className="md:col-span-2 flex justify-end">
              <button
                className="rounded-2xl bg-primary px-4 py-2 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-60"
                disabled={save.isPending}
                onClick={() => save.mutate()}
              >
                {save.isPending ? "Saving…" : "Save statement"}
              </button>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border bg-card p-5">
          <div className="text-sm font-semibold">Registered statements</div>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-xs text-muted-foreground">
                <tr>
                  <th className="py-2 pr-4">Type</th>
                  <th className="py-2 pr-4">Application</th>
                  <th className="py-2 pr-4">System</th>
                  <th className="py-2 pr-4">Scope</th>
                  <th className="py-2 pr-4">Residency</th>
                </tr>
              </thead>
              <tbody>
                {(data ?? []).map((s, i) => (
                  <tr key={s.id ?? i} className="border-t">
                    <td className="py-2 pr-4">{s.statementType}</td>
                    <td className="py-2 pr-4 font-mono text-xs">{s.applicationId}</td>
                    <td className="py-2 pr-4">{s.systemName}</td>
                    <td className="py-2 pr-4 font-mono text-xs">
                      {s.scope}:{s.scopeRef}
                    </td>
                    <td className="py-2 pr-4">{s.controls.residency}</td>
                  </tr>
                ))}
                {(data ?? []).length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-6 text-sm text-muted-foreground">
                      No statements yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </Page>
  );
}

function Field(props: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1 text-xs font-medium text-muted-foreground">{props.label}</div>
      {props.children}
    </div>
  );
}
