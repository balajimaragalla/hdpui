import React from "react";
import type { IcebergSnapshot } from "../../../lib/api/types";

export function IcebergSnapshotsPanel({ snapshots }: { snapshots: IcebergSnapshot[] }) {
  return (
    <div className="rounded-2xl border bg-card p-5">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm font-semibold">Iceberg history</div>
          <div className="mt-1 text-xs text-muted-foreground">
            Snapshots enable time-travel and safe backfills during Avro→Parquet/Iceberg migration.
          </div>
        </div>
      </div>

      <div className="mt-4 overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="text-xs text-muted-foreground">
            <tr>
              <th className="py-2 pr-4">Committed</th>
              <th className="py-2 pr-4">Snapshot ID</th>
              <th className="py-2 pr-4">Operation</th>
              <th className="py-2 pr-4">Summary</th>
            </tr>
          </thead>
          <tbody>
            {snapshots.length === 0 && (
              <tr>
                <td colSpan={4} className="py-6 text-sm text-muted-foreground">
                  No snapshots returned (API stub or dataset not Iceberg-backed).
                </td>
              </tr>
            )}
            {snapshots.map((s) => (
              <tr key={s.snapshotId} className="border-t">
                <td className="py-2 pr-4">{s.committedAt}</td>
                <td className="py-2 pr-4 font-mono text-xs">{s.snapshotId}</td>
                <td className="py-2 pr-4">{s.operation}</td>
                <td className="py-2 pr-4 text-xs text-muted-foreground">
                  {s.summary ? Object.entries(s.summary).slice(0, 3).map(([k, v]) => `${k}=${v}`).join(" • ") : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
