import React from "react";
import { Search } from "lucide-react";
import { Link, useNavigate } from "react-router";

export function TopNav() {
  const nav = useNavigate();
  const [q, setQ] = React.useState("");

  return (
    <header className="sticky top-0 z-40 border-b bg-background/70 backdrop-blur">
      <div className="mx-auto flex max-w-[1400px] items-center justify-between px-6 py-3">
        <Link to="/" className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-2xl bg-primary" />
          <div className="leading-tight">
            <div className="text-sm font-semibold">HDP Console</div>
            <div className="text-xs text-muted-foreground">Discovery • Governance • Quality • Lineage</div>
          </div>
        </Link>

        <div className="hidden w-[520px] items-center gap-2 rounded-2xl border bg-card px-3 py-2 lg:flex">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") nav(`/?q=${encodeURIComponent(q)}`);
            }}
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            placeholder="Search datasets, domains, applications, policies…"
          />
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-sm font-medium">Signed in</div>
            <div className="text-xs text-muted-foreground">Public-side workspace</div>
          </div>
          <div className="h-9 w-9 rounded-full border bg-card" />
        </div>
      </div>
    </header>
  );
}
