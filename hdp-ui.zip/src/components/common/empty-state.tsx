import React from "react";

export function EmptyState(props: { title: string; description?: string; children?: React.ReactNode }) {
  return (
    <div className="rounded-2xl border bg-card p-6">
      <div className="text-sm font-semibold">{props.title}</div>
      {props.description && <div className="mt-1 text-sm text-muted-foreground">{props.description}</div>}
      {props.children && <div className="mt-4">{props.children}</div>}
    </div>
  );
}
