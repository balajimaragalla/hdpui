import React from "react";
import { Page } from "../../components/layout/page";
import { useMutation } from "@tanstack/react-query";
import { endpoints } from "../../lib/api/endpoints";
import type { PublishDatasetRequest } from "../../lib/api/types";

export function PublishDatasetPage() {
  const [payload, setPayload] = React.useState<PublishDatasetRequest>({
    displayName: "",
    domain: "",
    ownerApplicationId: "",
    sourceType: "files",
    sourceRef: "",
    target: { catalog: "polaris", namespace: "ib", table: "" },
    migration: { preserveHistory: true, backfillMode: "incremental" }
  });

  const publish = useMutation({
    mutationFn: async () => endpoints.publishDataset(payload)
  });

  return (
    <Page title="Publish dataset" subtitle="Onboard files, Oracle extracts, or streams into Iceberg with governance + DQ">
      <div className="rounded-2xl border bg-card p-5">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <Field label="Display name">
            <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
              value={payload.displayName} onChange={(e) => setPayload({ ...payload, displayName: e.target.value })} />
          </Field>

          <Field label="Domain">
            <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
              value={payload.domain} onChange={(e) => setPayload({ ...payload, domain: e.target.value })} />
          </Field>

          <Field label="Owner application (NAR ID)">
            <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm font-mono"
              value={payload.ownerApplicationId} onChange={(e) => setPayload({ ...payload, ownerApplicationId: e.target.value })} />
          </Field>

          <Field label="Source type">
            <select className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
              value={payload.sourceType} onChange={(e) => setPayload({ ...payload, sourceType: e.target.value as any })}>
              <option value="files">Files (object store)</option>
              <option value="oracle">Oracle database extract</option>
              <option value="stream">Event stream</option>
            </select>
          </Field>

          <div className="md:col-span-2">
            <Field label="Source reference">
              <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
                placeholder={payload.sourceType === "files" ? "s3://bucket/path or gs://..." : payload.sourceType === "oracle" ? "jdbc:oracle:thin:@..." : "kafka://cluster/topic"}
                value={payload.sourceRef} onChange={(e) => setPayload({ ...payload, sourceRef: e.target.value })} />
            </Field>
          </div>

          <Field label="Target namespace">
            <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
              value={payload.target.namespace} onChange={(e) => setPayload({ ...payload, target: { ...payload.target, namespace: e.target.value } })} />
          </Field>

          <Field label="Target table">
            <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
              value={payload.target.table} onChange={(e) => setPayload({ ...payload, target: { ...payload.target, table: e.target.value } })} />
          </Field>

          <div className="md:col-span-2 flex items-center justify-between gap-4">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={payload.migration?.preserveHistory ?? true}
                onChange={(e) =>
                  setPayload({
                    ...payload,
                    migration: { ...(payload.migration ?? { backfillMode: "incremental", preserveHistory: true }), preserveHistory: e.target.checked }
                  })
                }
              />
              Preserve history (Iceberg snapshots)
            </label>

            <button
              className="rounded-2xl bg-primary px-4 py-2 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-60"
              disabled={publish.isPending}
              onClick={() => publish.mutate()}
            >
              {publish.isPending ? "Publishing…" : "Publish"}
            </button>
          </div>

          {publish.data?.id && (
            <div className="md:col-span-2 mt-2 rounded-2xl border bg-background p-3 text-sm">
              Published. Dataset ID: <span className="font-mono text-xs">{publish.data.id}</span>
            </div>
          )}
        </div>
      </div>
    </Page>
  );
}

function Field(props: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1 text-xs font-medium text-muted-foreground">{props.label}</div>
      {props.children}
    </div>
  );
}
