import React from "react";
import { Outlet } from "react-router";
import { TopNav } from "./top-nav";
import { SideNav } from "./side-nav";

export function AppShell() {
  return (
    <div className="min-h-dvh bg-background text-foreground">
      <TopNav />
      <div className="mx-auto grid max-w-[1400px] grid-cols-12 gap-6 px-6 py-6">
        <aside className="col-span-12 lg:col-span-3">
          <SideNav />
        </aside>
        <main className="col-span-12 lg:col-span-9">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
