import React from "react";
import type { DatasetDetailResponse } from "../../../lib/api/types";

export function AccessTab({ dataset }: { dataset: DatasetDetailResponse }) {
  return (
    <div className="rounded-2xl border bg-card p-5">
      <div className="text-sm font-semibold">Access model</div>
      <div className="mt-2 text-sm text-muted-foreground">
        This tab is where you enforce “registered authorised source / distributor”, residency and policy checks in the
        backend before issuing credentials or grants. The UI should only request access via API workflows.
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
        <KV k="Classification" v={dataset.classification} />
        <KV k="Owner application" v={dataset.ownerApplicationId} />
        <KV k="Suggested access" v="ABAC (policy-driven) + scoped service tokens" />
        <KV k="Audit" v="Per-request correlation id + immutable log entries" />
      </div>
    </div>
  );
}

function KV({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <div className="text-xs font-medium text-muted-foreground">{k}</div>
      <div className="mt-1 text-sm">{v}</div>
    </div>
  );
}
