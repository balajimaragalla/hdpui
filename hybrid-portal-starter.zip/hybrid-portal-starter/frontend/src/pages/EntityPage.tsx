import React, { useEffect, useState } from 'react';
import { getEntity, saveFavourite } from '../api';
import { useLocation } from 'react-router-dom';

export default function EntityPage(){
  const loc = useLocation();
  const q = new URLSearchParams(loc.search);
  const initialUrn = q.get('urn') || (loc.state as any)?.urn || '';
  const [urn, setUrn] = useState(initialUrn);
  const [entity, setEntity] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [note, setNote] = useState('');

  useEffect(() => {
    if (!urn) return;
    (async () => {
      setLoading(true);
      try {
        const data = await getEntity(urn);
        setEntity(data);
      } catch (e) {
        console.error(e);
        setEntity(null);
      } finally { setLoading(false); }
    })();
  }, [urn]);

  async function addFav(){
    const email = window.prompt('Enter your email for demo (will create user):', 'user@example.com') || '';
    if (!email) return;
    await saveFavourite(email, urn, note);
    alert('Favourite saved');
  }

  return (
    <div style={{ padding: 24 }}>
      <h1>Entity detail</h1>
      <div>
        <input placeholder="Entity URN" value={urn} onChange={e=>setUrn(e.target.value)} style={{width:'70%'}} />
        <button onClick={() => window.location.reload()}>Load</button>
      </div>
      {loading && <div>Loading...</div>}
      {entity && <pre style={{whiteSpace:'pre-wrap', marginTop:16}}>{JSON.stringify(entity, null, 2)}</pre>}
      <div style={{marginTop:16}}>
        <input placeholder="note (optional)" value={note} onChange={e=>setNote(e.target.value)} />
        <button onClick={addFav} style={{marginLeft:8}}>Add Favourite</button>
      </div>
    </div>
  );
}
