import { Router } from 'express';
import axios from 'axios';
import dotenv from 'dotenv';
dotenv.config();
const router = Router();

const OPENMETADATA_URL = process.env.OPENMETADATA_URL || 'http://localhost:8585';
const OPENMETADATA_TOKEN = process.env.OPENMETADATA_TOKEN || '';

const client = axios.create({
  baseURL: OPENMETADATA_URL,
  headers: OPENMETADATA_TOKEN ? { Authorization: `Bearer ${OPENMETADATA_TOKEN}` } : undefined,
  timeout: 10000,
});

// Simple search proxy: GET /api/metadata/search?q=...
router.get('/search', async (req, res) => {
  try {
    const q = String(req.query.q || '');
    // OpenMetadata search endpoint (v1) - adapt if your deployment differs
    const resp = await client.get('/api/v1/search', { params: { q }});
    res.json(resp.data);
  } catch (err: any) {
    console.error('search error', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Get entity by urn: GET /api/metadata/entity?urn=...
router.get('/entity', async (req, res) => {
  try {
    const urn = String(req.query.urn || '');
    if (!urn) return res.status(400).json({ error: 'urn is required' });
    const resp = await client.get(`/api/v1/entities/${encodeURIComponent(urn)}`);
    res.json(resp.data);
  } catch (err: any) {
    console.error('entity error', err.message);
    res.status(500).json({ error: err.message });
  }
});

export default router;
