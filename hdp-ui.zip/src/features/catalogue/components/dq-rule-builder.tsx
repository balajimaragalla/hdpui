import React from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import type { DqRule } from "../../../lib/api/types";

const RuleSchema = z.object({
  name: z.string().min(3),
  type: z.enum(["schema", "completeness", "integrity", "joinability", "timeliness"]),
  severity: z.enum(["low", "medium", "high"]),
  ownerApplicationId: z.string().min(2),
  enabled: z.boolean(),
  definition: z.string().min(2)
});

type RuleForm = z.infer<typeof RuleSchema>;

export function DqRuleBuilder(props: {
  ownerApplicationId: string;
  saving?: boolean;
  onSubmit: (r: DqRule) => Promise<void> | void;
}) {
  const form = useForm<RuleForm>({
    resolver: zodResolver(RuleSchema),
    defaultValues: {
      name: "",
      type: "completeness",
      severity: "medium",
      enabled: true,
      ownerApplicationId: props.ownerApplicationId,
      definition: "{\n  \"threshold\": 0.995,\n  \"columns\": [\"*\"],\n  \"window\": \"daily\"\n}"
    }
  });

  return (
    <form
      onSubmit={form.handleSubmit(async (v) => {
        const definition = JSON.parse(v.definition) as Record<string, unknown>;
        await props.onSubmit({
          name: v.name,
          type: v.type,
          severity: v.severity,
          ownerApplicationId: v.ownerApplicationId,
          enabled: v.enabled,
          definition
        });
        form.reset({ ...v, name: "" });
      })}
      className="rounded-2xl border bg-card p-5"
    >
      <div className="text-sm font-semibold">Add / update rule</div>
      <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
        <Field label="Rule name" error={form.formState.errors.name?.message}>
          <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm" {...form.register("name")} />
        </Field>

        <Field label="Owner application (NAR ID)" error={form.formState.errors.ownerApplicationId?.message}>
          <input
            className="w-full rounded-2xl border bg-background px-3 py-2 text-sm font-mono"
            {...form.register("ownerApplicationId")}
          />
        </Field>

        <Field label="Type">
          <select className="w-full rounded-2xl border bg-background px-3 py-2 text-sm" {...form.register("type")}>
            <option value="schema">Schema validation</option>
            <option value="completeness">Completeness</option>
            <option value="integrity">Integrity</option>
            <option value="joinability">Joinability</option>
            <option value="timeliness">Timeliness</option>
          </select>
        </Field>

        <Field label="Severity">
          <select className="w-full rounded-2xl border bg-background px-3 py-2 text-sm" {...form.register("severity")}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </Field>

        <div className="md:col-span-2">
          <Field label="Definition (JSON)" error={form.formState.errors.definition?.message}>
            <textarea
              className="min-h-[140px] w-full rounded-2xl border bg-background px-3 py-2 font-mono text-xs"
              {...form.register("definition")}
            />
          </Field>
        </div>

        <div className="flex items-center gap-2">
          <input type="checkbox" className="h-4 w-4" {...form.register("enabled")} />
          <div className="text-sm">Enabled</div>
        </div>

        <div className="md:col-span-2 flex justify-end">
          <button
            disabled={props.saving}
            type="submit"
            className="rounded-2xl bg-primary px-4 py-2 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-60"
          >
            {props.saving ? "Saving…" : "Save rule"}
          </button>
        </div>
      </div>
    </form>
  );
}

function Field(props: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1 text-xs font-medium text-muted-foreground">{props.label}</div>
      {props.children}
      {props.error && <div className="mt-1 text-xs text-red-600">{props.error}</div>}
    </div>
  );
}
