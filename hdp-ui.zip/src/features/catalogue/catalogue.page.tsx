import React from "react";
import { useQuery } from "@tanstack/react-query";
import { endpoints } from "../../lib/api/endpoints";
import { Page } from "../../components/layout/page";
import { EmptyState } from "../../components/common/empty-state";
import { Loading } from "../../components/common/loading";
import { Link, useSearchParams } from "react-router";

export function CataloguePage() {
  const [sp] = useSearchParams();
  const initial = sp.get("q") ?? "";
  const [q, setQ] = React.useState(initial);

  const { data, isLoading, error } = useQuery({
    queryKey: ["catalogue", q],
    queryFn: () => endpoints.catalogue(q)
  });

  return (
    <Page title="Catalogue" subtitle="Iceberg datasets, views, streams and governed extracts">
      <div className="mb-2 flex items-center gap-3">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search (e.g., ‘positions snapshot’, ‘oracle trades’, ‘dq:completeness’)…"
          className="w-full rounded-2xl border bg-card px-3 py-2 text-sm outline-none"
        />
      </div>

      {isLoading && <Loading />}
      {error && <EmptyState title="Couldn’t load catalogue" description="Check API connectivity and your session." />}

      {!isLoading && (data?.items?.length ?? 0) === 0 && (
        <EmptyState title="No datasets found" description="Try searching by domain, application, feed name, or classification." />
      )}

      <div className="grid grid-cols-1 gap-3">
        {data?.items?.map((d) => (
          <Link
            key={d.id}
            to={`/datasets/${encodeURIComponent(d.id)}`}
            className="rounded-2xl border bg-card p-4 hover:bg-accent"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-sm font-semibold">{d.displayName}</div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {d.domain} • {d.platform} • {d.format} • {d.classification}
                </div>
              </div>
              <div className="text-xs text-muted-foreground">{d.updatedAt}</div>
            </div>
          </Link>
        ))}
      </div>
    </Page>
  );
}
