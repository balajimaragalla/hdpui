import React from "react";
import type { DatasetDetailResponse } from "../../../lib/api/types";
import { IcebergSnapshotsPanel } from "../components/iceberg-snapshots-panel";

export function OverviewTab({ dataset }: { dataset: DatasetDetailResponse }) {
  return (
    <div className="grid grid-cols-1 gap-4">
      <div className="rounded-2xl border bg-card p-5">
        <div className="text-sm font-semibold">Summary</div>
        <div className="mt-2 grid grid-cols-1 gap-3 md:grid-cols-2">
          <KV k="Owner application (NAR ID)" v={dataset.ownerApplicationId} />
          <KV k="Tags" v={dataset.tags.join(", ") || "—"} />
          <KV k="Description" v={dataset.description ?? "—"} />
          <KV k="Dataset ID" v={dataset.id} />
        </div>
      </div>

      <IcebergSnapshotsPanel snapshots={dataset.snapshots} />
    </div>
  );
}

function KV({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <div className="text-xs font-medium text-muted-foreground">{k}</div>
      <div className="mt-1 text-sm">{v}</div>
    </div>
  );
}
