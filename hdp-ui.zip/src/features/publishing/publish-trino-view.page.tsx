import React from "react";
import { Page } from "../../components/layout/page";
import { useMutation } from "@tanstack/react-query";
import { endpoints } from "../../lib/api/endpoints";
import type { PublishViewRequest } from "../../lib/api/types";

export function PublishTrinoViewPage() {
  const [payload, setPayload] = React.useState<PublishViewRequest>({
    displayName: "",
    domain: "",
    ownerApplicationId: "",
    viewFqn: ""
  });

  const publish = useMutation({
    mutationFn: async () => endpoints.publishTrinoView(payload)
  });

  return (
    <Page title="Publish Trino view" subtitle="Register a view with contract + tests so consuming patterns don’t break">
      <div className="rounded-2xl border bg-card p-5">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <Field label="Display name">
            <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
              value={payload.displayName} onChange={(e) => setPayload({ ...payload, displayName: e.target.value })} />
          </Field>

          <Field label="Domain">
            <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm"
              value={payload.domain} onChange={(e) => setPayload({ ...payload, domain: e.target.value })} />
          </Field>

          <Field label="Owner application (NAR ID)">
            <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm font-mono"
              value={payload.ownerApplicationId} onChange={(e) => setPayload({ ...payload, ownerApplicationId: e.target.value })} />
          </Field>

          <Field label="View FQN">
            <input className="w-full rounded-2xl border bg-background px-3 py-2 text-sm font-mono"
              placeholder="catalog.schema.view_name"
              value={payload.viewFqn} onChange={(e) => setPayload({ ...payload, viewFqn: e.target.value })} />
          </Field>

          <div className="md:col-span-2 flex justify-end">
            <button
              className="rounded-2xl bg-primary px-4 py-2 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-60"
              disabled={publish.isPending}
              onClick={() => publish.mutate()}
            >
              {publish.isPending ? "Publishing…" : "Publish view"}
            </button>
          </div>

          {publish.data?.id && (
            <div className="md:col-span-2 mt-2 rounded-2xl border bg-background p-3 text-sm">
              Published. View ID: <span className="font-mono text-xs">{publish.data.id}</span>
            </div>
          )}
        </div>
      </div>
    </Page>
  );
}

function Field(props: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1 text-xs font-medium text-muted-foreground">{props.label}</div>
      {props.children}
    </div>
  );
}
