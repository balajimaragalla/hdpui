import React from "react";
import { Link, useLocation } from "react-router";
import { BookOpen, ClipboardCheck, GitBranch, Shield, Wrench } from "lucide-react";

const items = [
  { to: "/", label: "Catalogue", icon: BookOpen },
  { to: "/publishing/publish", label: "Publish dataset", icon: Wrench },
  { to: "/publishing/register-source", label: "Authority statements", icon: Shield },
  { to: "/operations/slos", label: "SLOs & freshness", icon: ClipboardCheck },
  { to: "/operations/runs", label: "Runs", icon: GitBranch },
  { to: "/governance/policies", label: "Policies", icon: Shield }
];

export function SideNav() {
  const loc = useLocation();
  return (
    <nav className="rounded-2xl border bg-card p-3">
      <div className="px-2 pb-2 text-xs font-semibold text-muted-foreground">Navigation</div>
      <div className="space-y-1">
        {items.map((it) => {
          const active = loc.pathname === it.to;
          const Icon = it.icon;
          return (
            <Link
              key={it.to}
              to={it.to}
              className={[
                "flex items-center gap-2 rounded-xl px-3 py-2 text-sm",
                active ? "bg-primary text-primary-foreground" : "hover:bg-accent"
              ].join(" ")}
            >
              <Icon className="h-4 w-4" />
              {it.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
