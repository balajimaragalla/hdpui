export type DatasetSummary = {
  id: string;
  displayName: string;
  domain: string;
  platform: "Iceberg" | "TrinoView" | "Stream" | "Extract";
  format: "Parquet" | "Iceberg" | "View" | "JSON" | "Avro";
  classification: "Public" | "Confidential" | "StrictlyConfidential";
  updatedAt: string;
};

export type DatasetListResponse = { items: DatasetSummary[] };

export type IcebergSnapshot = {
  snapshotId: string;
  committedAt: string;
  operation: string;
  summary?: Record<string, string>;
};

export type DatasetDetailResponse = {
  id: string;
  displayName: string;
  description?: string;
  domain: string;
  ownerApplicationId: string;
  platform: string;
  format: string;
  classification: string;
  tags: string[];
  schema: { name: string; type: string; nullable: boolean }[];
  snapshots: IcebergSnapshot[];
};

export type DqRuleType = "schema" | "completeness" | "integrity" | "joinability" | "timeliness";
export type DqSeverity = "low" | "medium" | "high";

export type DqRule = {
  id?: string;
  name: string;
  type: DqRuleType;
  severity: DqSeverity;
  ownerApplicationId: string;
  definition: Record<string, unknown>;
  enabled: boolean;
};

export type PublishDatasetRequest = {
  displayName: string;
  domain: string;
  ownerApplicationId: string;
  sourceType: "files" | "oracle" | "stream";
  sourceRef: string;
  target: { catalog: string; namespace: string; table: string };
  migration?: { preserveHistory: boolean; backfillMode: "full" | "incremental"; cutoverAt?: string };
  dqRules?: DqRule[];
  classifications?: string[];
};

export type PublishViewRequest = {
  displayName: string;
  domain: string;
  ownerApplicationId: string;
  viewFqn: string;
  semanticContract?: { description?: string; expectedColumns?: { name: string; type: string }[] };
  dqRules?: DqRule[];
};

export type RunListResponse = {
  items: { id: string; datasetId: string; startedAt: string; status: "success" | "failed" | "running" }[];
};

export type SloSummaryResponse = {
  items: { datasetId: string; freshnessMinutes: number; completeness: number; status: "ok" | "warning" | "breach" }[];
};

export type AuthorityStatement = {
  id?: string;
  statementType: "RegisteredAuthorisedSource" | "RegisteredAuthorisedDistributor";
  applicationId: string;
  systemName: string;
  dataDomain: string;
  scope: "dataset" | "topic" | "schema" | "view";
  scopeRef: string;
  validFrom: string;
  validTo?: string;
  controls: { residency: string; retention: string; accessModel: "RBAC" | "ABAC" | "Hybrid" };
};
