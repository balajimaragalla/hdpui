import React from "react";
import { Page } from "../../components/layout/page";
import { useQuery } from "@tanstack/react-query";
import { endpoints } from "../../lib/api/endpoints";
import { Loading } from "../../components/common/loading";
import { EmptyState } from "../../components/common/empty-state";

export function SlosPage() {
  const { data, isLoading, error } = useQuery({ queryKey: ["slos"], queryFn: () => endpoints.slos() });

  return (
    <Page title="SLOs & freshness" subtitle="Timeliness, completeness, and freshness at platform scale">
      {isLoading && <Loading />}
      {error && <EmptyState title="Couldn’t load SLOs" description="Check API connectivity and your session." />}

      <div className="rounded-2xl border bg-card p-5">
        <div className="text-sm font-semibold">Summary</div>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs text-muted-foreground">
              <tr>
                <th className="py-2 pr-4">Dataset</th>
                <th className="py-2 pr-4">Freshness (min)</th>
                <th className="py-2 pr-4">Completeness</th>
                <th className="py-2 pr-4">Status</th>
              </tr>
            </thead>
            <tbody>
              {(data?.items ?? []).map((s) => (
                <tr key={s.datasetId} className="border-t">
                  <td className="py-2 pr-4 font-mono text-xs">{s.datasetId}</td>
                  <td className="py-2 pr-4">{s.freshnessMinutes}</td>
                  <td className="py-2 pr-4">{Math.round(s.completeness * 1000) / 10}%</td>
                  <td className="py-2 pr-4">{s.status}</td>
                </tr>
              ))}
              {(data?.items ?? []).length === 0 && (
                <tr>
                  <td colSpan={4} className="py-6 text-sm text-muted-foreground">
                    No SLO rows yet (API stub).
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </Page>
  );
}
