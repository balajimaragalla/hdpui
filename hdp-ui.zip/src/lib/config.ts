export const config = {
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL as string,
  env: (import.meta.env.VITE_APP_ENV as string) ?? "dev"
};
