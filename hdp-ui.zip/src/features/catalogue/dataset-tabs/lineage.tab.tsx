import React from "react";
import type { DatasetDetailResponse } from "../../../lib/api/types";
import { LineageGraph } from "../components/lineage-graph";

export function LineageTab({ dataset }: { dataset: DatasetDetailResponse }) {
  return (
    <div className="grid grid-cols-1 gap-4">
      <div className="rounded-2xl border bg-card p-5">
        <div className="text-sm font-semibold">Lineage</div>
        <div className="mt-1 text-xs text-muted-foreground">
          Wire this to OpenMetadata lineage edges via your HDP API (do not call OpenMetadata from the browser).
        </div>
      </div>

      <LineageGraph datasetId={dataset.id} />
    </div>
  );
}
