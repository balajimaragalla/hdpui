import axios from 'axios';
const api = axios.create({ baseURL: import.meta.env.VITE_API_BASE || '/api' });

export async function searchMetadata(q: string){
  const res = await api.get('/metadata/search', { params: { q }});
  return res.data;
}

export async function getEntity(urn: string){
  const res = await api.get('/metadata/entity', { params: { urn }});
  return res.data;
}

export async function saveFavourite(userEmail: string, entityUrn: string, note?: string){
  const res = await api.post('/favourites', { userEmail, entityUrn, note });
  return res.data;
}

export async function listFavourites(email: string){
  const res = await api.get(`/favourites/${encodeURIComponent(email)}`);
  return res.data;
}
