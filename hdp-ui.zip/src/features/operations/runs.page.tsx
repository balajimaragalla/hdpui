import React from "react";
import { Page } from "../../components/layout/page";
import { useQuery } from "@tanstack/react-query";
import { endpoints } from "../../lib/api/endpoints";
import { Loading } from "../../components/common/loading";
import { EmptyState } from "../../components/common/empty-state";

export function RunsPage() {
  const { data, isLoading, error } = useQuery({ queryKey: ["runs"], queryFn: () => endpoints.runs() });

  return (
    <Page title="Runs" subtitle="Ingestion, validation, and publishing runs (with audit + trace ids in backend)">
      {isLoading && <Loading />}
      {error && <EmptyState title="Couldn’t load runs" description="Check API connectivity and your session." />}

      <div className="rounded-2xl border bg-card p-5">
        <div className="text-sm font-semibold">Latest</div>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs text-muted-foreground">
              <tr>
                <th className="py-2 pr-4">Run ID</th>
                <th className="py-2 pr-4">Dataset</th>
                <th className="py-2 pr-4">Started</th>
                <th className="py-2 pr-4">Status</th>
              </tr>
            </thead>
            <tbody>
              {(data?.items ?? []).map((r) => (
                <tr key={r.id} className="border-t">
                  <td className="py-2 pr-4 font-mono text-xs">{r.id}</td>
                  <td className="py-2 pr-4 font-mono text-xs">{r.datasetId}</td>
                  <td className="py-2 pr-4">{r.startedAt}</td>
                  <td className="py-2 pr-4">{r.status}</td>
                </tr>
              ))}
              {(data?.items ?? []).length === 0 && (
                <tr>
                  <td colSpan={4} className="py-6 text-sm text-muted-foreground">
                    No runs yet (API stub).
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </Page>
  );
}
