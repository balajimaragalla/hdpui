import React from "react";
import { Page } from "../../components/layout/page";

export function PoliciesPage() {
  return (
    <Page title="Policies" subtitle="Centralised policies enforced by HDP API (ABAC/RBAC, residency, retention, approvals)">
      <div className="rounded-2xl border bg-card p-5">
        <div className="text-sm font-semibold">Policy model</div>
        <div className="mt-2 text-sm text-muted-foreground">
          Treat policies as code in the backend (OPA / Cedar / custom engine). UI is for discoverability, review,
          and approvals — not enforcement.
        </div>

        <div className="mt-4 rounded-2xl border bg-background p-4 font-mono text-xs">
          {"allow if classification in {Public, Confidential} and user.domain == dataset.domain\n"}
          {"deny if classification == StrictlyConfidential and requesterSide == Public\n"}
          {"require AuthorityStatement(RAS/RAD) for publishing + cross-domain distribution\n"}
        </div>
      </div>
    </Page>
  );
}
