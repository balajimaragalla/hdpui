import { api } from "./client";
import type {
  AuthorityStatement,
  DatasetDetailResponse,
  DatasetListResponse,
  DqRule,
  PublishDatasetRequest,
  PublishViewRequest,
  RunListResponse,
  SloSummaryResponse
} from "./types";

export const endpoints = {
  catalogue: (q: string) => api<DatasetListResponse>(`/catalogue/datasets?q=${encodeURIComponent(q)}`),
  dataset: (datasetId: string) => api<DatasetDetailResponse>(`/catalogue/datasets/${encodeURIComponent(datasetId)}`),

  dqRules: (datasetId: string) => api<DqRule[]>(`/dq/datasets/${encodeURIComponent(datasetId)}/rules`),
  upsertDqRule: (datasetId: string, rule: DqRule) =>
    api<DqRule>(`/dq/datasets/${encodeURIComponent(datasetId)}/rules`, { method: "POST", body: rule }),

  publishDataset: (req: PublishDatasetRequest) => api<{ id: string }>(`/publishing/datasets`, { method: "POST", body: req }),
  publishTrinoView: (req: PublishViewRequest) => api<{ id: string }>(`/publishing/trino-views`, { method: "POST", body: req }),

  authorityStatements: () => api<AuthorityStatement[]>(`/governance/authority-statements`),
  upsertAuthorityStatement: (s: AuthorityStatement) =>
    api<AuthorityStatement>(`/governance/authority-statements`, { method: "POST", body: s }),

  runs: () => api<RunListResponse>(`/ops/runs`),
  slos: () => api<SloSummaryResponse>(`/ops/slos`)
};
