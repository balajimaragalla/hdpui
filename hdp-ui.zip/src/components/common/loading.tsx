import React from "react";

export function Loading() {
  return (
    <div className="rounded-2xl border bg-card p-6">
      <div className="animate-pulse space-y-3">
        <div className="h-4 w-1/3 rounded bg-accent" />
        <div className="h-3 w-2/3 rounded bg-accent" />
        <div className="h-3 w-1/2 rounded bg-accent" />
      </div>
    </div>
  );
}
