# HDP Console UI (React)

Production-grade UI scaffold for Hybrid Data Platform (HDP): catalogue, publishing, governance, operations.
- React 19 + TypeScript + Vite
- Tailwind + modern design primitives
- TanStack Query for server state
- React Router
- Lineage graph using @xyflow/react (React Flow)

## Quick start

```bash
pnpm install
pnpm dev
```

Create a `.env` from `.env.example`.

## Architecture notes

This UI **does not** call Polaris/OpenMetadata/Trino directly. It calls an internal **HDP API** (BFF / façade)
that enforces tenancy, authorisation, audit logging, and deterministic policies.
