import React from "react";
import {
  Background,
  Controls,
  MiniMap,
  ReactFlow,
  type Edge,
  type Node
} from "@xyflow/react";

const initialNodes: Node[] = [
  { id: "src1", position: { x: 0, y: 50 }, data: { label: "Oracle ExaCC: trades" }, type: "default" },
  { id: "ingest", position: { x: 240, y: 50 }, data: { label: "Ingest: Extract + Validate" }, type: "default" },
  { id: "iceberg", position: { x: 520, y: 50 }, data: { label: "Iceberg table (HDP)" }, type: "default" },
  { id: "view", position: { x: 820, y: 50 }, data: { label: "Trino view (published)" }, type: "default" }
];

const initialEdges: Edge[] = [
  { id: "e1", source: "src1", target: "ingest", animated: true },
  { id: "e2", source: "ingest", target: "iceberg", animated: true },
  { id: "e3", source: "iceberg", target: "view" }
];

export function LineageGraph(props: { datasetId: string }) {
  const [nodes] = React.useState<Node[]>(initialNodes);
  const [edges] = React.useState<Edge[]>(initialEdges);

  return (
    <div className="h-[520px] overflow-hidden rounded-2xl border bg-card">
      <div className="border-b px-4 py-3">
        <div className="text-sm font-semibold">Technical lineage</div>
        <div className="mt-1 text-xs text-muted-foreground">Dataset: {props.datasetId}</div>
      </div>

      <div className="h-[468px]">
        <ReactFlow nodes={nodes} edges={edges} fitView>
          <MiniMap />
          <Controls />
          <Background />
        </ReactFlow>
      </div>
    </div>
  );
}
