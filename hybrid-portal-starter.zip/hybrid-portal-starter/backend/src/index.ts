import express from 'express';
import cors from 'cors';
import metadataRoutes from './routes/metadata';
import favouritesRoutes from './routes/favourites';
import { PrismaClient } from '@prisma/client';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const prisma = new PrismaClient();
app.set('prisma', prisma);

// Health
app.get('/api/health', (req, res) => res.json({ ok: true }));

// Routes
app.use('/api/metadata', metadataRoutes);
app.use('/api/favourites', favouritesRoutes);

// Basic root
app.get('/', (req, res) => res.send('Hybrid Data Platform Portal Backend'));

const port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log(`Backend listening on http://localhost:${port}`);
});
