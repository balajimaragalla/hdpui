import React, { useState } from 'react';
import { searchMetadata } from '../api';
import { Link, useNavigate } from 'react-router-dom';

export default function Home(){
  const [q, setQ] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function doSearch(){
    setLoading(true);
    try {
      const data = await searchMetadata(q);
      // expect OpenMetadata v1 search shape; adapt as needed
      const items = data?.data || data?.entities || data?.hits || data?.results || [];
      setResults(Array.isArray(items) ? items : []);
    } catch (e) {
      console.error(e);
      setResults([]);
    } finally { setLoading(false); }
  }

  return (
    <div style={{ padding: 24 }}>
      <h1>Hybrid Data Platform — Portal (Starter)</h1>
      <div>
        <input placeholder="Search datasets, tables, pipelines..." value={q} onChange={e=>setQ(e.target.value)} style={{width: '60%'}} />
        <button onClick={doSearch} disabled={loading} style={{marginLeft:8}}>Search</button>
      </div>
      <div style={{marginTop:16}}>
        {loading && <div>Loading...</div>}
        {!loading && results.length===0 && <div>No results</div>}
        <ul>
          {results.map((it:any, idx:number) => {
            // attempt to extract displayName or name
            const title = it?.displayName || it?.name || it?.entity?.displayName || it?.value?.displayName || JSON.stringify(it)?.slice(0,60);
            const urn = it?.urn || it?.entity?.urn || it?.value?.urn || '';
            return (
              <li key={idx}>
                <a href={`/entity?urn=${encodeURIComponent(urn)}`}>{title}</a>
              </li>
            );
          })}
        </ul>
      </div>
      <div style={{marginTop:24}}>
        <h3>Quick Demo</h3>
        <button onClick={() => { navigate('/entity', { state: { urn: 'urn:li:dataset:sample' }})}}>Open sample entity (demo)</button>
      </div>
    </div>
  );
}
