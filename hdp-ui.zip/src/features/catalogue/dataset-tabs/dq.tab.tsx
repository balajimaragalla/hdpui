import React from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import type { DatasetDetailResponse, DqRule } from "../../../lib/api/types";
import { endpoints } from "../../../lib/api/endpoints";
import { queryClient } from "../../../lib/query-client";
import { DqRuleBuilder } from "../components/dq-rule-builder";

export function DqTab({ dataset }: { dataset: DatasetDetailResponse }) {
  const { data } = useQuery({
    queryKey: ["dqRules", dataset.id],
    queryFn: () => endpoints.dqRules(dataset.id)
  });

  const upsert = useMutation({
    mutationFn: async (rule: DqRule) => endpoints.upsertDqRule(dataset.id, rule),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["dqRules", dataset.id] });
    }
  });

  return (
    <div className="grid grid-cols-1 gap-4">
      <div className="rounded-2xl border bg-card p-5">
        <div className="text-sm font-semibold">Rules</div>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs text-muted-foreground">
              <tr>
                <th className="py-2 pr-4">Name</th>
                <th className="py-2 pr-4">Type</th>
                <th className="py-2 pr-4">Severity</th>
                <th className="py-2 pr-4">Owner</th>
                <th className="py-2 pr-4">Enabled</th>
              </tr>
            </thead>
            <tbody>
              {(data ?? []).map((r) => (
                <tr key={r.id ?? r.name} className="border-t">
                  <td className="py-2 pr-4 font-medium">{r.name}</td>
                  <td className="py-2 pr-4">{r.type}</td>
                  <td className="py-2 pr-4">{r.severity}</td>
                  <td className="py-2 pr-4 font-mono text-xs">{r.ownerApplicationId}</td>
                  <td className="py-2 pr-4">{r.enabled ? "Yes" : "No"}</td>
                </tr>
              ))}
              {(data ?? []).length === 0 && (
                <tr>
                  <td colSpan={5} className="py-6 text-sm text-muted-foreground">
                    No rules yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <DqRuleBuilder
        ownerApplicationId={dataset.ownerApplicationId}
        onSubmit={async (rule) => upsert.mutate(rule)}
        saving={upsert.isPending}
      />
    </div>
  );
}
