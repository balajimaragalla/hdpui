import React from "react";
import { useParams } from "react-router";
import { useQuery } from "@tanstack/react-query";
import { endpoints } from "../../lib/api/endpoints";
import { Page } from "../../components/layout/page";
import { Loading } from "../../components/common/loading";
import { EmptyState } from "../../components/common/empty-state";
import { OverviewTab } from "./dataset-tabs/overview.tab";
import { SchemaTab } from "./dataset-tabs/schema.tab";
import { DqTab } from "./dataset-tabs/dq.tab";
import { LineageTab } from "./dataset-tabs/lineage.tab";
import { AccessTab } from "./dataset-tabs/access.tab";

const tabs = ["Overview", "Schema", "Data Quality", "Lineage", "Access"] as const;
type Tab = (typeof tabs)[number];

export function DatasetPage() {
  const { datasetId } = useParams();
  const [tab, setTab] = React.useState<Tab>("Overview");

  const { data, isLoading, error } = useQuery({
    queryKey: ["dataset", datasetId],
    queryFn: () => endpoints.dataset(datasetId!),
    enabled: !!datasetId
  });

  if (isLoading) return <Loading />;
  if (error || !data)
    return <EmptyState title="Dataset not available" description="The dataset may not exist or you lack access." />;

  return (
    <Page title={data.displayName} subtitle={`${data.domain} • ${data.platform} • ${data.format} • ${data.classification}`}>
      <div className="mb-4 flex flex-wrap gap-2">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={[
              "rounded-2xl border px-3 py-1.5 text-sm",
              tab === t ? "bg-primary text-primary-foreground" : "bg-card hover:bg-accent"
            ].join(" ")}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "Overview" && <OverviewTab dataset={data} />}
      {tab === "Schema" && <SchemaTab dataset={data} />}
      {tab === "Data Quality" && <DqTab dataset={data} />}
      {tab === "Lineage" && <LineageTab dataset={data} />}
      {tab === "Access" && <AccessTab dataset={data} />}
    </Page>
  );
}
