import React from "react";
import { createBrowserRouter } from "react-router";
import { AppShell } from "./components/layout/app-shell";

import { CataloguePage } from "./features/catalogue/catalogue.page";
import { DatasetPage } from "./features/catalogue/dataset.page";

import { RegisterSourcePage } from "./features/publishing/register-source.page";
import { PublishDatasetPage } from "./features/publishing/publish-dataset.page";
import { PublishTrinoViewPage } from "./features/publishing/publish-trino-view.page";

import { SlosPage } from "./features/operations/slos.page";
import { RunsPage } from "./features/operations/runs.page";

import { PoliciesPage } from "./features/governance/policies.page";

export const router = createBrowserRouter([
  {
    element: <AppShell />,
    children: [
      { path: "/", element: <CataloguePage /> },
      { path: "/datasets/:datasetId", element: <DatasetPage /> },

      { path: "/publishing/register-source", element: <RegisterSourcePage /> },
      { path: "/publishing/publish", element: <PublishDatasetPage /> },
      { path: "/publishing/trino-view", element: <PublishTrinoViewPage /> },

      { path: "/operations/slos", element: <SlosPage /> },
      { path: "/operations/runs", element: <RunsPage /> },

      { path: "/governance/policies", element: <PoliciesPage /> }
    ]
  }
]);
