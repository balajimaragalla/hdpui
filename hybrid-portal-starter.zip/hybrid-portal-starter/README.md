# Hybrid Data Platform — Self-Service Portal (Starter)

Minimal runnable starter codebase:
- **backend/** — Node + Express + TypeScript, proxies OpenMetadata and uses Prisma + Postgres for app data (favourites, users)
- **frontend/** — React (Vite) + TypeScript, simple search and entity detail UI
- **docker-compose.yml** — Postgres + optional OpenMetadata (dev) + backend + frontend
- **.env.example** — environment variables

## Quickstart (local)

1. Install prerequisites: Node 18+, pnpm or npm, Docker (for Postgres/OpenMetadata if desired), Prisma CLI.
2. Copy env: `cp .env.example .env`
3. Start Postgres (via Docker Compose) or provide DATABASE_URL to an existing Postgres:
   ```bash
   docker compose up -d postgres
   ```
4. Initialize Prisma:
   ```bash
   cd backend
   npm install
   npx prisma generate
   npx prisma migrate dev --name init
   npm run dev
   ```
5. Start frontend:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
6. Open `http://localhost:5173` for the frontend. Backend runs at `http://localhost:4000`.

Notes:
- Backend forwards metadata API calls to OpenMetadata. Set `OPENMETADATA_URL` in .env to your OpenMetadata endpoint (e.g., http://localhost:8585).
- This starter is intentionally minimal — authentication, production hardening, and advanced features should be added.

