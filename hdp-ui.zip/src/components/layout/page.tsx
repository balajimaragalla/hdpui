import React from "react";

export function Page(props: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-4">
      <div className="rounded-2xl border bg-card p-5">
        <div className="text-lg font-semibold">{props.title}</div>
        {props.subtitle && <div className="mt-1 text-sm text-muted-foreground">{props.subtitle}</div>}
      </div>
      {props.children}
    </div>
  );
}
